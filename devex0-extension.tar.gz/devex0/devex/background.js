// No background logic needed for this extension, but file required by manifest.

